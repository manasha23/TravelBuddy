import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IBooking } from './booking.model';
import { FormsModule } from '@angular/forms';  

@Component({
  selector: 'app-booking',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent {
  searchTerm: string = ''; 

  bookings: IBooking[] = [
    { 
      tourID: 1, 
      tourName: "Venice", 
      duration: "7 Days", 
      price: 3500, 
      image: "assets/venice.jpg", 
      rating: 9.2 
    },
    { 
      tourID: 2, 
      tourName: "Paris", 
      duration: "5 Days", 
      price: 2000, 
      image: "assets/paris.jpg", 
      rating: 8.7 
    },
    { 
      tourID: 3, 
      tourName: "Moscow", 
      duration: "8 Days", 
      price: 3500, 
      image: "assets/moscow.jpg", 
      rating: 8.9 
    },
    { 
      tourID: 4, 
      tourName: "Egypt", 
      duration: "10 Days", 
      price: 4000, 
      image: "assets/egypt.jpg", 
      rating: 9.0 
    },
    { 
      tourID: 5, 
      tourName: "Spain", 
      duration: "12 Days", 
      price: 4500, 
      image: "assets/spain.jpg", 
      rating: 9.3 
    },
    { 
      tourID: 6, 
      tourName: "Japan", 
      duration: "8 Days", 
      price: 3800, 
      image: "assets/japan.jpg", 
      rating: 8.6 
    },
    { 
      tourID: 7, 
      tourName: "Australia", 
      duration: "15 Days", 
      price: 5000, 
      image: "assets/australia.jpg", 
      rating: 9.4 
    },
    { 
      tourID: 8, 
      tourName: "South Africa", 
      duration: "9 Days", 
      price: 4200, 
      image: "assets/southafrica.jpg", 
      rating: 9.1 
    },
    { 
      tourID: 9, 
      tourName: "New Zealand", 
      duration: "7 Days", 
      price: 3700, 
      image: "assets/newzealand.jpg", 
      rating: 8.8 
    },
    { 
      tourID: 10, 
      tourName: "Canada", 
      duration: "10 Days", 
      price: 4600, 
      image: "assets/canada.jpg", 
      rating: 9.5 
    },
    { 
      tourID: 11, 
      tourName: "Greece", 
      duration: "7 Days", 
      price: 3300, 
      image: "assets/greece.jpg", 
      rating: 8.7 
    },
    { 
      tourID: 12, 
      tourName: "Iceland", 
      duration: "8 Days", 
      price: 4100, 
      image: "assets/iceland.jpg", 
      rating: 9.0 
    }
  ]
  

 
  get filteredBookings() {
    return this.bookings.filter(booking =>
      booking.tourName.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }
}
