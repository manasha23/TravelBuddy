export class Contact{
    constructor(
        public name='',
        public email='',
        public message=''
    )
    {}
}