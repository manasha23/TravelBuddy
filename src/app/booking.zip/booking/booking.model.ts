export interface IBooking {
    tourID: number;
    tourName: string;
    duration: string;
    price: number;
    image: string;
    rating: number;
}